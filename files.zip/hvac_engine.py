"""
HVAC Design & Calculation engine (pure Python, no UI dependencies).

Pre-design calculations: cooling load -> chillers -> pumps -> cooling tower.
Simplified CLTD / SHGC method. Verify against ASHRAE CLTD/RTS or HAP,
manufacturer data and applicable codes (ASHRAE, BNBC) before issue.
"""
import math
import re

# --------------------------------------------------------------------------
# Defaults, labels and input groups
# --------------------------------------------------------------------------
DEFAULTS = dict(
    proj="Sample Office Tower", btype="Commercial Office", loc="Dhaka, Bangladesh",
    floors=8, area=6400, sys="Water-cooled chilled water",
    tdb=35, twb=28, tin=24, rh=50, rep=8,
    wU=.6, wC=14, rU=.5, rC=24, gU=3, shgc=.45, sol=220, pS=75, pL=55,
    faP=2.5, faA=.3, ach=.2, sf=10, fanTR=.15,
    div=85, csf=5, cwS=6.5, cwR=12.5, cop=5.6, stb="N+1",
    pm="Primary-secondary", len=250, fr=2.5, fit=30, vl=4, ev=6, co=8, cv=3, st=0,
    hs=10, pe=75, me=92, cLen=100, cEv=6, cTw=4, cSt=12,
    rng=5.5, app=4, cell=500, gph=38, cyc=4, dr=.005,
    sQ=100, sH=30, sFl="Water", sT=8, sPe=75, sMe=92, sHs=0,
)

ROOM_KEYS = ["n", "a", "h", "w", "g", "r", "p", "l", "e"]
DEFAULT_ROOMS = [
    dict(zip(ROOM_KEYS, r)) for r in [
        ["Open office", 700, 3, 300, 160, 0, 70, 12, 15],
        ["Conference", 120, 3, 60, 20, 0, 40, 12, 10],
        ["Reception", 80, 3, 40, 30, 0, 8, 15, 8],
        ["Server room", 40, 3, 30, 0, 0, 2, 15, 300],
        ["Pantry", 50, 3, 25, 0, 0, 6, 10, 20],
    ]
]

FLUIDS = ["Water", "Ethylene glycol 20%", "Ethylene glycol 30%",
          "Propylene glycol 20%", "Propylene glycol 30%"]

# key: (label, unit, options-or-None)
LABELS = dict(
    proj=("Project name", "", None),
    btype=("Building type", "", ["Commercial Office", "Hospital", "Hotel", "Shopping Mall",
                                 "Residential", "Industrial", "Education", "Data Center"]),
    loc=("Location", "", None),
    floors=("Number of floors", "", None),
    area=("Total building area", "m²", None),
    sys=("HVAC system type", "", ["Water-cooled chilled water", "Air-cooled chilled water",
                                  "VRF", "Ducted split / package"]),
    tdb=("Outdoor design DB", "°C", None), twb=("Outdoor design WB", "°C", None),
    tin=("Indoor design temp", "°C", None), rh=("Indoor RH", "%", None),
    rep=("Typical floors repeated", "×", None),
    wU=("Wall U", "W/m²K", None), wC=("Wall CLTD", "K", None),
    rU=("Roof U", "W/m²K", None), rC=("Roof CLTD", "K", None),
    gU=("Glass U", "W/m²K", None), shgc=("Glass SHGC", "", None),
    sol=("Peak solar flux", "W/m²", None),
    pS=("Sensible / person", "W", None), pL=("Latent / person", "W", None),
    faP=("Fresh air / person", "L/s", None), faA=("Fresh air / area", "L/s·m²", None),
    ach=("Infiltration", "ACH", None), sf=("Load safety factor", "%", None),
    fanTR=("AHU/FCU fan power", "kW/TR", None),
    div=("Diversity factor", "%", None), csf=("Chiller design margin", "%", None),
    cwS=("CHW supply", "°C", None), cwR=("CHW return", "°C", None),
    cop=("Chiller COP", "", None),
    stb=("Standby provision", "", ["N+1", "None", "100% standby set"]),
    pm=("CHW pumping", "", ["Primary-secondary", "Primary only"]),
    len=("CHW distribution equiv. length", "m", None),
    fr=("Friction rate", "m/100 m", None), fit=("Fittings allowance", "% of pipe", None),
    vl=("Valves & strainers", "m", None), ev=("Evaporator ΔP", "m", None),
    co=("Coil ΔP", "m", None), cv=("Control valve ΔP", "m", None),
    st=("Static head (open loop)", "m", None), hs=("Head safety", "%", None),
    pe=("Pump efficiency", "%", None), me=("Motor efficiency", "%", None),
    cLen=("CW pipe equiv. length", "m", None), cEv=("Condenser ΔP", "m", None),
    cTw=("Tower nozzle/spray", "m", None), cSt=("Tower lift (static)", "m", None),
    rng=("Tower range", "K", None), app=("Approach to WB", "K", None),
    cell=("Max cell size", "tower tons", None), gph=("Fan efficiency", "gpm/hp", None),
    cyc=("Cycles of concentration", "", None), dr=("Drift loss", "% of flow", None),
    sQ=("Flow", "m³/h", None), sH=("Total dynamic head", "m", None),
    sFl=("Fluid", "", FLUIDS), sT=("Fluid temp", "°C", None),
    sPe=("Pump efficiency", "%", None), sMe=("Motor efficiency", "%", None),
    sHs=("Static part of system head", "m", None),
)

GROUPS = {
    "proj": ["proj", "btype", "loc", "floors", "area", "sys"],
    "des": ["tdb", "twb", "tin", "rh", "rep", "sf"],
    "env": ["wU", "wC", "rU", "rC", "gU", "shgc", "sol", "pS", "pL", "faP", "faA", "ach", "fanTR"],
    "chi": ["div", "csf", "cwS", "cwR", "cop", "stb"],
    "pmp": ["pm", "len", "fr", "fit", "vl", "ev", "co", "cv", "st", "hs", "pe", "me",
            "cLen", "cEv", "cTw", "cSt"],
    "sel": ["sQ", "sH", "sFl", "sT", "sPe", "sMe", "sHs"],
    "ct": ["rng", "app", "cell", "gph", "cyc", "dr"],
}

# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
STD_CHILLER_TR = [50, 75, 100, 125, 150, 200, 250, 300, 350, 400, 500, 600, 700, 800, 1000]
STD_MOTOR_KW = [.75, 1.1, 1.5, 2.2, 3, 4, 5.5, 7.5, 11, 15, 18.5, 22, 30, 37, 45, 55,
                75, 90, 110, 132, 160, 200, 250, 315]


class Res(dict):
    """dict with attribute access (res.TR)."""
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(k)


def fmt(x, d=1):
    """Thousands separators + fixed decimals; '–' for non-finite."""
    try:
        x = float(x)
    except (TypeError, ValueError):
        return "–"
    return f"{x:,.{d}f}" if math.isfinite(x) else "–"


def psat(T):
    return .61121 * math.exp((18.678 - T / 234.5) * (T / (257.14 + T)))


def w_rh(T, rh):
    p = psat(T) * rh / 100
    return .622 * p / (101.325 - p)


def w_wb(db, wb):
    ws = .622 * psat(wb) / (101.325 - psat(wb))
    return ((2501 - 2.326 * wb) * ws - 1.006 * (db - wb)) / (2501 + 1.86 * db - 4.186 * wb)


def up(arr, v):
    for x in arr:
        if x >= v:
            return x
    return arr[-1]


def rho(T, fluid):
    w = 1000 * (1 - (T + 288.9414) / (508929.2 * (T + 68.12963)) * (T - 3.9863) ** 2)
    m = {"Water": 1, "Ethylene glycol 20%": 1.025, "Ethylene glycol 30%": 1.04,
         "Propylene glycol 20%": 1.015, "Propylene glycol 30%": 1.025}
    return w * m.get(fluid, 1)


def pump(Q, H, rh, pe, me):
    """Q m³/h, H m, rh kg/m³, pe & me in %."""
    hy = rh * 9.81 * Q / 3600 * H / 1000
    sh = hy / (pe / 100)
    mk = up(STD_MOTOR_KW, sh * 1.15)
    return Res(hy=hy, sh=sh, mk=mk, hp=mk * 1.341, inp=sh / (me / 100))


def pump_type(Q, H):
    if H > 100:
        return "Multistage centrifugal"
    if Q > 500:
        return "Horizontal split-case"
    if Q >= 40 or H > 40:
        return "End-suction (frame/close-coupled)"
    return "In-line / end-suction"


def size_chillers(req):
    best = None
    for n in range(1, 7):
        if req > 150 and n < 2:
            continue
        s = up(STD_CHILLER_TR, req / n)
        sc = (n * s - req) / req + .04 * (n - 1)
        if best is None or sc < best["sc"]:
            best = dict(n=n, s=s, sc=sc)
    return best


# --------------------------------------------------------------------------
# Main calculation
# --------------------------------------------------------------------------
def validate(S):
    """Return list of blocking input errors."""
    errs = []
    if S["cwR"] <= S["cwS"]:
        errs.append("CHW return temperature must be higher than CHW supply.")
    return errs


def calc(S, rooms):
    """Returns Res, or None when the modelled load is zero."""
    s = S
    dT = s["tdb"] - s["tin"]
    Wo = w_wb(s["tdb"], s["twb"])
    Wi = w_rh(s["tin"], s["rh"])
    dW = 1000 * (Wo - Wi)
    k = 1 + s["sf"] / 100

    T = dict.fromkeys(["wall", "roof", "gc", "sol", "lt", "eq", "ps", "pl",
                       "fs", "fl", "ins", "inl", "area", "ppl"], 0.0)
    room_rows, fa_unit = [], 0.0
    for r in rooms:
        w = s["wU"] * r["w"] * s["wC"]
        ro = s["rU"] * r["r"] * s["rC"]
        gc = s["gU"] * r["g"] * dT
        so = r["g"] * s["shgc"] * s["sol"]
        lt = r["l"] * r["a"]
        eq = r["e"] * r["a"]
        ps = r["p"] * s["pS"]
        pl = r["p"] * s["pL"]
        fq = r["p"] * s["faP"] + r["a"] * s["faA"]
        fs = 1.2 * fq * dT
        fl = 3 * fq * dW
        iq = s["ach"] * r["a"] * r["h"] / 3.6
        ins = 1.2 * iq * dT
        inl = 3 * iq * dW
        sen_r = (w + ro + gc + so + lt + eq + ps + fs + ins) / 1000
        lat_r = (pl + fl + inl) / 1000
        room_rows.append(dict(n=r["n"], sen=sen_r, lat=lat_r, tot=sen_r + lat_r,
                              tr=(sen_r + lat_r) / 3.517))
        fa_unit += fq
        for key, val in dict(wall=w, roof=ro, gc=gc, sol=so, lt=lt, eq=eq, ps=ps, pl=pl,
                             fs=fs, fl=fl, ins=ins, inl=inl, area=r["a"], ppl=r["p"]).items():
            T[key] += val

    m = s["rep"] / 1000
    sen = (T["wall"] + T["roof"] + T["gc"] + T["sol"] + T["lt"] + T["eq"] + T["ps"]
           + T["fs"] + T["ins"]) * m
    lat = (T["pl"] + T["fl"] + T["inl"]) * m
    sub = sen + lat
    if sub <= 0:
        return None
    tot = sub * k
    TR = tot / 3.517
    BTU = tot * 3412.14
    shr = sen / sub

    # --- chillers
    conn = TR
    req = conn * s["div"] / 100 * (1 + s["csf"] / 100)
    ch = size_chillers(req)
    nd, sz = ch["n"], ch["s"]
    ns = 1 if s["stb"] == "N+1" else 0 if s["stb"] == "None" else nd
    ni = nd + ns
    dTc = s["cwR"] - s["cwS"]
    dF = dTc * 1.8
    gpmC = sz * 24 / dF
    m3C = sz * 3.517 / (1.163 * dTc)
    kwTR = 3.517 / s["cop"]
    kwC = sz * kwTR
    hrC = sz * 3.517 * (1 + 1 / s["cop"])
    dutyTR = nd * sz

    # --- pumps
    rw = rho(8, "Water")
    hl = lambda length, ex: length * s["fr"] / 100 * (1 + s["fit"] / 100) + ex
    k2 = 1 + s["hs"] / 100
    dist = hl(s["len"], s["vl"] + s["co"] + s["cv"] + s["st"])
    ps_ = s["pm"] == "Primary-secondary"
    Hp = (s["ev"] + hl(40, s["vl"])) * k2 if ps_ else (s["ev"] + dist) * k2
    Hs = dist * k2 if ps_ else 0
    Hc = (s["cEv"] + hl(s["cLen"], s["vl"] + s["cTw"] + s["cSt"])) * k2
    pp = pump(m3C, Hp, rw, s["pe"], s["me"])
    m3T = m3C * nd
    sp = pump(m3T / nd, Hs, rw, s["pe"], s["me"])
    cwq = hrC / (1.163 * s["rng"])
    cp = pump(cwq, Hc, rho(32, "Water"), s["pe"], s["me"])

    # --- cooling tower
    hrT = hrC * nd
    cwT = cwq * nd
    lct = s["twb"] + s["app"]
    ect = lct + s["rng"]
    tt = hrT / 4.396
    nc = math.ceil(tt / s["cell"])
    gpmT = cwT * 4.403
    fanKw = gpmT / s["gph"] * .746
    evp = .0018 * s["rng"] * cwT
    drf = cwT * s["dr"] / 100
    bd = evp / (s["cyc"] - 1) - drf
    mk = evp + bd + drf

    # --- electrical
    ac = s["fanTR"] * TR
    kwCh = kwC * nd
    kwPP = pp.inp * nd
    kwSP = sp.inp * nd if ps_ else 0
    kwCP = cp.inp * nd
    kwTot = kwCh + kwPP + kwSP + kwCP + fanKw + ac

    # --- stand-alone pump selection module
    rs = rho(s["sT"], s["sFl"])
    sl = pump(s["sQ"], s["sH"], rs, s["sPe"], s["sMe"])

    return Res(T=T, rooms=room_rows, sen=sen, lat=lat, tot=tot, TR=TR, BTU=BTU, shr=shr,
               req=req, nd=nd, sz=sz, ns=ns, ni=ni, gpmC=gpmC, m3C=m3C, kwC=kwC, hrC=hrC,
               pp=pp, sp=sp, cp=cp, Hp=Hp, Hs=Hs, Hc=Hc, ps=ps_, m3T=m3T, cwq=cwq, hrT=hrT,
               cwT=cwT, lct=lct, ect=ect, tt=tt, nc=nc, gpmT=gpmT, fanKw=fanKw, evp=evp,
               drf=drf, bd=bd, mk=mk, kwTot=kwTot, kwCh=kwCh, kwPP=kwPP, kwSP=kwSP,
               kwCP=kwCP, ac=ac, dist=dist, rw=rw, dutyTR=dutyTR, kwTR=kwTR, conn=conn,
               dTc=dTc, dW=dW, Wo=Wo, Wi=Wi, m=m, fa_total=s["rep"] * fa_unit,
               sl=sl, rs=rs)


def design_checks(S, rooms, r):
    """Warnings list (same rules as the original HTML tool)."""
    s, w = S, []
    cA = s["rep"] * sum(x["a"] for x in rooms)
    if s["area"] and abs(cA - s["area"]) / s["area"] > .25:
        w.append(f"Modelled conditioned area ({fmt(cA, 0)} m²) differs from the stated "
                 f"building area ({fmt(s['area'], 0)} m²) by more than 25%.")
    if s["app"] < 3:
        w.append("Approach below 3 K needs an oversized tower; confirm with the vendor.")
    if r.lct > 32:
        w.append(f"Leaving tower water {fmt(r.lct, 1)} °C may exceed the chiller’s allowed "
                 "condenser water temperature.")
    if r.dTc < 4:
        w.append("CHW ΔT below 4 K raises pump energy; consider 5–7 K.")
    if cA and r.tot * 1000 / cA > 200:
        w.append(f"Load density {fmt(r.tot * 1000 / cA, 0)} W/m² is high for most buildings; "
                 "check inputs.")
    if r.shr < .6:
        w.append("Low sensible heat ratio: confirm latent and fresh air inputs.")
    return w


# --------------------------------------------------------------------------
# Pump duty point vs. manufacturer curve
# --------------------------------------------------------------------------
def parse_curve(text):
    pts = []
    for line in (text or "").splitlines():
        parts = [p for p in re.split(r"[,\s]+", line.strip()) if p]
        if len(parts) < 2:
            continue
        try:
            a, b = float(parts[0]), float(parts[1])
        except ValueError:
            continue
        if math.isfinite(a) and math.isfinite(b):
            pts.append((a, b))
    return sorted(pts)


def duty_point(S, pts):
    """System curve through design duty + intersection with catalog curve."""
    Hs = min(S["sHs"], S["sH"])
    k = (S["sH"] - Hs) / ((S["sQ"] * S["sQ"]) or 1)
    sys_h = lambda Q: Hs + k * Q * Q
    mx = max(S["sQ"] * 1.6, pts[-1][0] if pts else 0)
    my = max([S["sH"] * 1.5] + [p[1] for p in pts] + [1])

    def hp(Q):
        if len(pts) < 2 or Q < pts[0][0] or Q > pts[-1][0]:
            return None
        for i in range(1, len(pts)):
            if Q <= pts[i][0]:
                a, b = pts[i - 1], pts[i]
                return a[1] + (b[1] - a[1]) * (Q - a[0]) / ((b[0] - a[0]) or 1)
        return None

    op, pv = None, None
    for i in range(401):
        Q = mx * i / 400
        h = hp(Q)
        if h is None:
            continue
        d = h - sys_h(Q)
        if pv and pv["d"] >= 0 and d < 0:
            t = pv["d"] / (pv["d"] - d)
            op = dict(Q=pv["Q"] + (Q - pv["Q"]) * t, H=pv["h"] + (h - pv["h"]) * t)
            break
        pv = dict(Q=Q, h=h, d=d)
    return dict(sys=sys_h, mx=mx, my=my, op=op)
