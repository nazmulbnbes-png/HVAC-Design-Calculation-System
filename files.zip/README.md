# HVAC Design & Calculation System

Pre-design HVAC calculator (Streamlit): **cooling load → chillers → pumps → cooling tower → report**.
Simplified CLTD/SHGC method. Results are for pre-design only; verify with ASHRAE CLTD/RTS or HAP,
manufacturer data and applicable codes (ASHRAE, BNBC) before issue.

## Features
- Room-by-room cooling load (editable table, add/remove rooms)
- Chiller sizing (diversity, margin, N+1 / 100% standby)
- CHW primary-secondary or primary-only pumps, condenser pumps, head build-up
- Pump selection + duty point against a pasted manufacturer curve
- Cooling tower sizing and water balance
- Printable HTML report, save / load project as `.json`

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy from GitHub (free)
GitHub Pages only serves static files, so a Python app needs a Python host. Easiest:

1. Push this folder to a GitHub repo (`app.py`, `hvac_engine.py`, `requirements.txt`, `.streamlit/` at the repo root).
2. Go to <https://share.streamlit.io> → sign in with GitHub → **Create app**.
3. Choose the repo, branch `main`, main file path `app.py` → **Deploy**.

You get a public `https://<name>.streamlit.app` link. Every `git push` redeploys automatically.
Alternatives: Hugging Face Spaces (Streamlit SDK), Render, Railway.

## Files
| File | Purpose |
|---|---|
| `app.py` | Streamlit user interface |
| `hvac_engine.py` | Calculation engine (pure Python, no UI dependency) |
| `requirements.txt` | Dependencies |
| `.streamlit/config.toml` | Theme / server settings |
